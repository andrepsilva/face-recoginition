const playwright = require('playwright')
const faaceapi = require("face-api.js")
const { FaceDetection } = require('face-api.js')
void (async () => {
    const browser = await playwright.chromium.launch()
    const page = await browser.newPage()


    await page.goto('https://reidobacalhaurp.com.br/portfolio-item/favela-chique-14-11-2018/')
    const imgArray = await page.evaluate(()=>{
        const html_c = [...document.getElementsByClassName("attachment-thumbnail size-thumbnail")]
        const links = []
        html_c.forEach(e => {links.push(e.src)})
        return links
    })

    // await page.goto('https://reidobacalhaurp.com.br/fotos')
    // const Events = await page.evaluate(() => {
    //     const trueEv = []
       
    //     const Number = [...document.getElementsByClassName("desc")].length
    //     const Ev = [...document.getElementsByClassName("entry-title")]
       
    //     Ev.forEach(e => {trueEv.push(e.innerText)})
       
    //     const Arr = trueEv.filter(function(este, i) {return trueEv.indexOf(este) === i;})
    //     return { "Events": Arr, "EventsNumber": Number }
    // })


    imgArray.forEach(img => {
        const faces = await faaceapi.detectAllFaces(img)
        console.log(faces)
    })
    await browser.close()

})()
